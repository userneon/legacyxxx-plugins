# LEGACY-X Hud

Shows the LEGACY-X Workshop HUD (repository `legacyxxx-workshop`) to players. The Workshop addon draws; this
plugin creates the `custom_hud_layout` entity through **PanoramaManager** and fills it per player: texts by
Label id, states by toggling classes. Every id is listed in the addon's `CONTRACT.md`.

**Status: first version, a pipeline test.** A welcome announcement (`legacyx_notify` → `ann`) is shown to a
player a few seconds after joining, and `!lxhud` shows it again. Rank card, match card, knife vote and the
`!admin` panel come after this works on a server.

## Needs

* CounterStrikeSharp 1.0.374 or newer (the `custom_hud_layout` API).
* The Workshop addon published and sent to players: `mm_client_extra_addons <ID>` (MultiAddonManager).
* `LEGACYX_HUD_ENABLED=true` (default) in `CounterStrikeSharp/.env`.

## If nothing shows

1. Console at start: `[LEGACY-X Hud] Ready. Layout ...`, or `Could not spawn ...: <reason>`.
2. Try the compiled layout name in `.env`: `LEGACYX_HUD_NOTIFY_LAYOUT=panorama/layout/custom_game/legacyx_notify.vxml_c`
   (CONTRACT.md says the source `.xml` path, PanoramaManager's example uses `.vxml_c`; the real one is found by testing).
3. `css_panorama_diag` (from PanoramaManager) shows the entity and per-player state.
4. The player must have downloaded the addon: map change once after the first join.

## Build

`dotnet build LegacyX-Hud/LegacyX-Hud.csproj -c Release`. The class and method names of PanoramaManager
(`Panorama.Init/Spawn/Shutdown`, `PanelHandle.SetVariableFor/SetClassFor/CaptureInput/Dispose`) were taken from
its README; if the compiler disagrees, adjust `LegacyXHud.cs`, nothing else depends on them.
